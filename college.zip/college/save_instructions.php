<?php
session_start();
require_once 'config.php';
require_once 'check_auth.php';

// Добавляем CORS заголовки
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Обрабатываем preflight запросы
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// Проверяем авторизацию
if (!checkAuth()) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Не авторизован']);
    exit;
}

// Проверяем роль администратора
if ($_SESSION['role'] !== 'admin') {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Доступ запрещен. Требуются права администратора.']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Метод не разрешен']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);

if (!$input || !isset($input['content'])) {
    echo json_encode(['success' => false, 'message' => 'Отсутствует содержимое для сохранения']);
    exit;
}

$content = $input['content'];

try {
    $pdo = getDBConnection();
    
    // Создаем таблицу для инструкций, если она не существует
    $createTableQuery = "
        CREATE TABLE IF NOT EXISTS instructions (
            id INT AUTO_INCREMENT PRIMARY KEY,
            content LONGTEXT NOT NULL,
            updated_by INT NOT NULL,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (updated_by) REFERENCES users(id)
        )
    ";
    $pdo->exec($createTableQuery);
    
    // Проверяем, есть ли уже запись
    $checkStmt = $pdo->prepare("SELECT id FROM instructions LIMIT 1");
    $checkStmt->execute();
    $exists = $checkStmt->fetch();
    
    if ($exists) {
        // Обновляем существующую запись
        $updateStmt = $pdo->prepare("
            UPDATE instructions 
            SET content = ?, updated_by = ?, updated_at = NOW() 
            WHERE id = ?
        ");
        $updateStmt->execute([$content, $_SESSION['user_id'], $exists['id']]);
    } else {
        // Создаем новую запись
        $insertStmt = $pdo->prepare("
            INSERT INTO instructions (content, updated_by) 
            VALUES (?, ?)
        ");
        $insertStmt->execute([$content, $_SESSION['user_id']]);
    }
    
    echo json_encode([
        'success' => true,
        'message' => 'Инструкции успешно сохранены',
        'timestamp' => date('Y-m-d H:i:s')
    ]);

} catch (PDOException $e) {
    error_log("Database error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Ошибка сервера при сохранении']);
} catch (Exception $e) {
    error_log("General error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Общая ошибка: ' . $e->getMessage()]);
}
?>
