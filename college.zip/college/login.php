<?php
session_start();
require_once 'config.php';

// Добавляем CORS заголовки
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Обрабатываем preflight запросы
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Метод не разрешен']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);

if (!$input) {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';
} else {
    $username = $input['username'] ?? '';
    $password = $input['password'] ?? '';
}

if (empty($username) || empty($password)) {
    echo json_encode(['success' => false, 'message' => 'Заполните все поля']);
    exit;
}

try {
    $pdo = getDBConnection();
    
    // Получаем пользователя с информацией о роли (без проверки роли)
    $stmt = $pdo->prepare("
        SELECT u.*, r.role_name, r.role_description 
        FROM users u 
        JOIN roles r ON u.role_id = r.id 
        WHERE (u.username = ? OR u.email = ?) AND u.is_active = 1
    ");
    $stmt->execute([$username, $username]);
    $user = $stmt->fetch();

    if (!$user) {
        echo json_encode(['success' => false, 'message' => 'Неверный логин или пароль']);
        exit;
    }

    // Проверяем пароль
    if (!password_verify($password, $user['password_hash'])) {
        echo json_encode(['success' => false, 'message' => 'Неверный логин или пароль']);
        exit;
    }

    // Обновляем время последнего входа
    $updateStmt = $pdo->prepare("UPDATE users SET last_login = NOW() WHERE id = ?");
    $updateStmt->execute([$user['id']]);

    // Сохраняем данные в сессии
    $_SESSION['user_id'] = $user['id'];
    $_SESSION['username'] = $user['username'];
    $_SESSION['role'] = $user['role_name'];
    $_SESSION['full_name'] = trim($user['last_name'] . ' ' . $user['first_name'] . ' ' . $user['middle_name']);

    // Возвращаем успешный ответ
    echo json_encode([
        'success' => true,
        'message' => 'Успешная авторизация',
        'user' => [
            'id' => $user['id'],
            'username' => $user['username'],
            'email' => $user['email'],
            'full_name' => $_SESSION['full_name'],
            'role' => $user['role_name'],
            'role_description' => $user['role_description'],
            'group_number' => $user['group_number']
        ]
    ]);

} catch (PDOException $e) {
    error_log("Database error: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Ошибка сервера: ' . $e->getMessage()]);
} catch (Exception $e) {
    error_log("General error: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Общая ошибка: ' . $e->getMessage()]);
}
?>
