<?php
session_start();
require_once 'config.php';
require_once 'check_auth.php';

header('Content-Type: application/json; charset=utf-8');

if (!checkAuth()) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Не авторизован']);
    exit;
}

try {
    $pdo = getDBConnection();
    
    $stmt = $pdo->prepare("
        SELECT u.*, r.role_name, r.role_description 
        FROM users u 
        JOIN roles r ON u.role_id = r.id 
        WHERE u.id = ?
    ");
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch();

    if (!$user) {
        http_response_code(404);
        echo json_encode(['success' => false, 'message' => 'Пользователь не найден']);
        exit;
    }

    echo json_encode([
        'success' => true,
        'user' => [
            'id' => $user['id'],
            'username' => $user['username'],
            'email' => $user['email'],
            'first_name' => $user['first_name'],
            'last_name' => $user['last_name'],
            'middle_name' => $user['middle_name'],
            'full_name' => trim($user['last_name'] . ' ' . $user['first_name'] . ' ' . $user['middle_name']),
            'role' => $user['role_name'],
            'role_description' => $user['role_description'],
            'group_number' => $user['group_number'],
            'phone' => $user['phone'],
            'last_login' => $user['last_login'],
            'created_at' => $user['created_at']
        ]
    ]);

} catch (PDOException $e) {
    error_log("Database error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Ошибка сервера']);
}
?>
