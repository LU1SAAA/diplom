// Глобальные переменные
let currentUser = null
let templates = []
let currentFilter = "all"

// Инициализация при загрузке страницы
document.addEventListener("DOMContentLoaded", () => {
  checkAuth()
  loadTemplates()
  initializeEventListeners()
})

// Проверка авторизации
async function checkAuth() {
  // Сначала проверяем localStorage (для демо-режима и кэширования)
  const currentUserData = localStorage.getItem("currentUser")
  const authMode = localStorage.getItem("authMode") || "demo"

  if (!currentUserData) {
    // Пользователь не авторизован
    document.getElementById("loginBtn").style.display = "block"
    document.getElementById("userProfile").style.display = "none"
    return
  }

  try {
    currentUser = JSON.parse(currentUserData)

    if (authMode === "server") {
      // В серверном режиме пытаемся получить свежие данные
      try {
        const response = await fetch("get_user_info.php")
        const data = await response.json()

        if (data.success) {
          currentUser = data.user
          localStorage.setItem("currentUser", JSON.stringify(currentUser))
        } else {
          console.warn("Server authentication failed, using cached data")
        }
      } catch (error) {
        console.warn("Server not available, using cached data:", error)
      }
    }

    // Обновляем интерфейс с данными пользователя
    updateUserInterface()
  } catch (error) {
    console.error("Ошибка парсинга данных пользователя:", error)
    // Очищаем поврежденные данные
    localStorage.removeItem("currentUser")
    localStorage.removeItem("authMode")
    document.getElementById("loginBtn").style.display = "block"
    document.getElementById("userProfile").style.display = "none"
  }
}

// Обновление интерфейса для авторизованного пользователя
function updateUserInterface() {
  if (currentUser) {
    document.getElementById("loginBtn").style.display = "none"
    document.getElementById("userProfile").style.display = "flex"
    document.getElementById("userName").textContent = currentUser.full_name
    document.getElementById("userRole").textContent = getRoleDisplayName(currentUser.role)

    // Показываем админ-панель для администраторов
    if (currentUser.role === "admin") {
      document.getElementById("adminControls").style.display = "block"
    }

    // Показываем ссылку на управление пользователями для администраторов
    const usersLink = document.getElementById("usersLink")
    if (usersLink && currentUser.role === "admin") {
      usersLink.style.display = "block"
    }

    // Инициализируем обработчик профиля
    initializeUserProfile()
  }
}

// Получение отображаемого названия роли
function getRoleDisplayName(role) {
  const roleNames = {
    admin: "Администратор",
    teacher: "Преподаватель",
    student: "Студент",
  }
  return roleNames[role] || role
}

// Загрузка шаблонов
async function loadTemplates() {
  const authMode = localStorage.getItem("authMode") || "demo"

  try {
    if (authMode === "server") {
      // Пытаемся загрузить с сервера
      const response = await fetch("templates.php")
      const data = await response.json()

      if (data.success) {
        templates = data.templates
        renderTemplates()
        return
      }
    }
  } catch (error) {
    console.warn("Server not available, using demo data:", error)
  }

  // Используем демо-данные или загружаем из localStorage
  loadDemoTemplates()
  renderTemplates()

  // Скрываем загрузку и показываем контент
  document.getElementById("loadingContainer").style.display = "none"
  document.getElementById("mainContent").style.display = "block"
}

// Загрузка демо-шаблонов
function loadDemoTemplates() {
  // Пытаемся загрузить сохраненные шаблоны из localStorage
  const savedTemplates = localStorage.getItem("demo_templates")

  if (savedTemplates) {
    try {
      templates = JSON.parse(savedTemplates)
      return
    } catch (error) {
      console.warn("Error parsing saved templates:", error)
    }
  }

  // Используем базовые демо-данные
  templates = getMockTemplates()
  saveTemplatesToStorage()
}

// Сохранение шаблонов в localStorage
function saveTemplatesToStorage() {
  localStorage.setItem("demo_templates", JSON.stringify(templates))
}

// Моковые данные для демонстрации
function getMockTemplates() {
  return [
    {
      id: 1,
      title: "Отчет по учебной практике",
      description:
        "Шаблон отчета по учебной практической подготовке для студентов. Включает все необходимые разделы: индивидуальное задание, дневник практики, текстовой отчет, заключение и список литературы.",
      category: "educational",
      file_name: "educational_practice_report.docx",
      file_path: "college/files/УП Отчет.docx.pdf",
      file_size: 45632,
      mime_type: "application/pdf",
      preview_image: "/placeholder.svg?height=300&width=200",
      download_count: 156,
      is_active: true,
      created_at: "2024-01-15T10:30:00Z",
      updated_at: "2024-06-20T14:22:00Z",
    },
    {
      id: 2,
      title: "Отчет по производственной практике",
      description:
        "Шаблон отчета по производственной практической подготовке. Содержит характеристику практиканта, описание организации, дневник прохождения практики и текстовой отчет.",
      category: "production",
      file_name: "production_practice_report.docx",
      file_path: "college/files/Отчет пп.docx.pdf",
      file_size: 52148,
      mime_type: "application/pdf",
      preview_image: "/placeholder.svg?height=300&width=200",
      download_count: 203,
      is_active: true,
      created_at: "2024-01-15T10:30:00Z",
      updated_at: "2024-06-22T09:15:00Z",
    },
  ]
}

// Отрисовка шаблонов
function renderTemplates() {
  const grid = document.getElementById("templatesGrid")
  const filteredTemplates = currentFilter === "all" ? templates : templates.filter((t) => t.category === currentFilter)

  if (filteredTemplates.length === 0) {
    grid.innerHTML =
      '<div class="no-templates" style="text-align: center; padding: 40px; color: #6b7280;">Шаблоны не найдены</div>'
    return
  }

  grid.innerHTML = filteredTemplates.map((template) => createTemplateCard(template)).join("")
}

// Создание карточки шаблона
function createTemplateCard(template) {
  const isAdmin = currentUser && currentUser.role === "admin"
  const categoryName = template.category === "educational" ? "Учебная" : "Производственная"
  const categoryClass = template.category

  return `
        <div class="template-card" data-category="${template.category}">
            <div class="template-card-header">
                <h3 class="template-card-title">${template.title}</h3>
                <span class="template-badge ${categoryClass}">${categoryName}</span>
            </div>
            
            <div class="template-preview" onclick="showPreview(${template.id})">
                <img src="${template.preview_image}" alt="Предпросмотр ${template.title}">
                <div class="preview-overlay">
                    <svg class="preview-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path>
                        <circle cx="12" cy="12" r="3"></circle>
                    </svg>
                </div>
            </div>
            
            <div class="template-card-body">
                <p class="template-description">${template.description}</p>
                
                <div class="template-stats">
                    <span>${formatFileSize(template.file_size)}</span>
                    <span>${template.download_count} скачиваний</span>
                </div>
                
                <div class="template-updated">
                    Обновлено: ${formatDate(template.updated_at)}
                </div>
                
                <div class="template-actions">
                    <button class="btn btn-primary btn-full" onclick="downloadTemplate(${template.id})">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
                            <polyline points="7,10 12,15 17,10"></polyline>
                            <line x1="12" y1="15" x2="12" y2="3"></line>
                        </svg>
                        Скачать
                    </button>
                    ${
                      isAdmin
                        ? `
                        <button class="btn btn-outline btn-sm" onclick="editTemplate(${template.id})">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
                                <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
                            </svg>
                        </button>
                        <button class="btn btn-outline btn-sm" onclick="deleteTemplate(${template.id})" style="color: #dc2626; border-color: #dc2626;">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <polyline points="3,6 5,6 21,6"></polyline>
                                <path d="M19,6v14a2,2,0,0,1-2,2H7a2,2,0,0,1-2-2V6m3,0V4a2,2,0,0,1,2-2h4a2,2,0,0,1,2,2V6"></path>
                            </svg>
                        </button>
                    `
                        : ""
                    }
                </div>
            </div>
        </div>
    `
}

// Инициализация обработчиков событий
function initializeEventListeners() {
  // Фильтры
  document.querySelectorAll(".tab-btn").forEach((btn) => {
    btn.addEventListener("click", function () {
      // Обновляем активную вкладку
      document.querySelectorAll(".tab-btn").forEach((b) => b.classList.remove("active"))
      this.classList.add("active")

      // Обновляем фильтр
      currentFilter = this.dataset.category
      renderTemplates()
    })
  })

  // Формы
  document.getElementById("editTemplateForm").addEventListener("submit", handleEditSubmit)
  document.getElementById("addTemplateForm").addEventListener("submit", handleAddSubmit)

  // Закрытие модальных окон по клику вне их
  document.querySelectorAll(".modal").forEach((modal) => {
    modal.addEventListener("click", function (e) {
      if (e.target === this) {
        this.classList.remove("show")
        this.style.display = "none"
      }
    })
  })
}

// Показ предпросмотра
function showPreview(templateId) {
  const template = templates.find((t) => t.id === templateId)
  if (!template) return

  document.getElementById("previewTitle").textContent = template.title
  document.getElementById("previewImage").src = template.preview_image
  document.getElementById("previewImage").alt = `Предпросмотр ${template.title}`
  document.getElementById("previewDescription").textContent = template.description
  document.getElementById("previewSize").textContent = `Размер: ${formatFileSize(template.file_size)}`
  document.getElementById("previewDownloads").textContent = `Скачиваний: ${template.download_count}`

  document.getElementById("previewDownloadBtn").onclick = () => downloadTemplate(templateId)

  showModal("previewModal")
}

// Скачивание шаблона
async function downloadTemplate(templateId) {
  const template = templates.find((t) => t.id === templateId)
  if (!template) return

  try {
    // Создаем ссылку для скачивания
    const link = document.createElement("a")
    link.href = template.file_path
    link.download = template.file_name
    link.target = "_blank"
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)

    // Увеличиваем счетчик скачиваний
    template.download_count++
    saveTemplatesToStorage()
    renderTemplates()

    showNotification("success", "Файл скачан", `Шаблон "${template.title}" успешно скачан`)

    // Закрываем модальное окно предпросмотра, если оно открыто
    closePreviewModal()
  } catch (error) {
    console.error("Ошибка скачивания:", error)
    showNotification("error", "Ошибка", "Не удалось скачать файл")
  }
}

// Редактирование шаблона
function editTemplate(templateId) {
  const template = templates.find((t) => t.id === templateId)
  if (!template) return

  document.getElementById("editTemplateId").value = template.id
  document.getElementById("editTitle").value = template.title
  document.getElementById("editDescription").value = template.description
  document.getElementById("editCategory").value = template.category

  showModal("editModal")
}

// Удаление шаблона
function deleteTemplate(templateId) {
  const template = templates.find((t) => t.id === templateId)
  if (!template) return

  if (confirm(`Вы уверены, что хотите удалить шаблон "${template.title}"?`)) {
    // Удаляем шаблон из массива
    templates = templates.filter((t) => t.id !== templateId)
    saveTemplatesToStorage()
    renderTemplates()

    showNotification("success", "Шаблон удален", `Шаблон "${template.title}" успешно удален`)
  }
}

// Обработка отправки формы редактирования
async function handleEditSubmit(e) {
  e.preventDefault()

  const formData = new FormData(e.target)
  const templateId = Number.parseInt(formData.get("templateId"))
  const title = formData.get("title")
  const description = formData.get("description")
  const category = formData.get("category")

  try {
    const authMode = localStorage.getItem("authMode") || "demo"

    if (authMode === "server") {
      // Серверный режим - отправляем на сервер
      const response = await fetch(`templates.php?action=update&id=${templateId}`, {
        method: "POST",
        body: formData,
      })

      const data = await response.json()

      if (data.success) {
        showNotification("success", "Успешно", "Шаблон обновлен")
        closeEditModal()
        loadTemplates()
      } else {
        showNotification("error", "Ошибка", data.message || "Не удалось обновить шаблон")
      }
    } else {
      // Демо-режим - обновляем локально
      const templateIndex = templates.findIndex((t) => t.id === templateId)

      if (templateIndex !== -1) {
        templates[templateIndex] = {
          ...templates[templateIndex],
          title,
          description,
          category,
          updated_at: new Date().toISOString(),
        }

        saveTemplatesToStorage()
        renderTemplates()
        closeEditModal()
        showNotification("success", "Успешно", "Шаблон обновлен")
      } else {
        showNotification("error", "Ошибка", "Шаблон не найден")
      }
    }
  } catch (error) {
    console.error("Ошибка обновления:", error)
    showNotification("error", "Ошибка", "Не удалось обновить шаблон")
  }
}

// Показ модального окна добавления
function showAddTemplateModal() {
  document.getElementById("addTemplateForm").reset()
  showModal("addModal")
}

// Обработка отправки формы добавления
async function handleAddSubmit(e) {
  e.preventDefault()

  const formData = new FormData(e.target)
  const title = formData.get("title")
  const description = formData.get("description")
  const category = formData.get("category")
  const file = formData.get("file")

  try {
    const authMode = localStorage.getItem("authMode") || "demo"

    if (authMode === "server") {
      // Серверный режим - отправляем на сервер
      const response = await fetch("templates.php?action=create", {
        method: "POST",
        body: formData,
      })

      const data = await response.json()

      if (data.success) {
        showNotification("success", "Успешно", "Шаблон добавлен")
        closeAddModal()
        loadTemplates()
      } else {
        showNotification("error", "Ошибка", data.message || "Не удалось добавить шаблон")
      }
    } else {
      // Демо-режим - добавляем локально
      const newId = Math.max(...templates.map((t) => t.id), 0) + 1

      const newTemplate = {
        id: newId,
        title,
        description,
        category,
        file_name: file ? file.name : "demo_template.docx",
        file_path: "/placeholder.svg?height=300&width=200", // В демо-режиме используем заглушку
        file_size: file ? file.size : 50000,
        mime_type: file ? file.type : "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        preview_image: "/placeholder.svg?height=300&width=200",
        download_count: 0,
        is_active: true,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      }

      templates.push(newTemplate)
      saveTemplatesToStorage()
      renderTemplates()
      closeAddModal()
      showNotification("success", "Успешно", "Шаблон добавлен (демо-режим)")
    }
  } catch (error) {
    console.error("Ошибка добавления:", error)
    showNotification("error", "Ошибка", "Не удалось добавить шаблон")
  }
}

// Функции управления модальными окнами
function showModal(modalId) {
  const modal = document.getElementById(modalId)
  modal.style.display = "flex"
  modal.classList.add("show")
}

function closePreviewModal() {
  const modal = document.getElementById("previewModal")
  modal.classList.remove("show")
  modal.style.display = "none"
}

function closeEditModal() {
  const modal = document.getElementById("editModal")
  modal.classList.remove("show")
  modal.style.display = "none"
}

function closeAddModal() {
  const modal = document.getElementById("addModal")
  modal.classList.remove("show")
  modal.style.display = "none"
}

// Показ уведомлений
function showNotification(type, title, message) {
  const notification = document.getElementById("notification")
  const icon = document.getElementById("notificationIcon")
  const titleEl = document.getElementById("notificationTitle")
  const messageEl = document.getElementById("notificationMessage")

  // Устанавливаем тип уведомления
  notification.className = `notification ${type}`

  // Устанавливаем иконку
  const icons = {
    success: "✓",
    error: "✕",
    info: "i",
  }
  icon.textContent = icons[type] || "i"

  // Устанавливаем текст
  titleEl.textContent = title
  messageEl.textContent = message

  // Показываем уведомление
  notification.classList.add("show")

  // Автоматически скрываем через 5 секунд
  setTimeout(() => {
    notification.classList.remove("show")
  }, 5000)
}

// Вспомогательные функции
function formatFileSize(bytes) {
  if (bytes === 0) return "0 Bytes"
  const k = 1024
  const sizes = ["Bytes", "KB", "MB", "GB"]
  const i = Math.floor(Math.log(bytes) / Math.log(k))
  return Number.parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i]
}

function formatDate(dateString) {
  const date = new Date(dateString)
  return date.toLocaleDateString("ru-RU", {
    year: "numeric",
    month: "long",
    day: "numeric",
  })
}

// Обработка ошибок
window.addEventListener("error", (e) => {
  console.error("JavaScript error:", e.error)
  showNotification("error", "Ошибка", "Произошла ошибка в работе приложения")
})

// Обработка необработанных промисов
window.addEventListener("unhandledrejection", (e) => {
  console.error("Unhandled promise rejection:", e.reason)
  showNotification("error", "Ошибка", "Произошла ошибка при выполнении запроса")
})

// Добавляем обработчик клика по профилю пользователя для выхода
function initializeUserProfile() {
  const userProfile = document.getElementById("userProfile")

  if (userProfile && currentUser) {
    userProfile.style.cursor = "pointer"
    userProfile.title = "Нажмите для выхода"

    userProfile.addEventListener("click", async () => {
      if (confirm("Вы уверены, что хотите выйти?")) {
        const authMode = localStorage.getItem("authMode") || "demo"

        if (authMode === "server") {
          try {
            await fetch("logout.php", { method: "POST" })
          } catch (error) {
            console.warn("Server logout failed:", error)
          }
        }

        // Очищаем локальные данные
        localStorage.removeItem("currentUser")
        localStorage.removeItem("authMode")
        window.location.href = "index.html"
      }
    })
  }
}
