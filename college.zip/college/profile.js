// Глобальные переменные
let currentUser = null
let userReports = []
let groups = []
let students = []
let selectedGroup = null
let selectedStudent = null

// Инициализация при загрузке страницы
document.addEventListener("DOMContentLoaded", () => {
  checkAuth()
  initializeEventListeners()
})

// Проверка авторизации
async function checkAuth() {
  const currentUserData = localStorage.getItem("currentUser")
  const authMode = localStorage.getItem("authMode") || "demo"

  if (!currentUserData) {
    window.location.href = "login.html"
    return
  }

  try {
    currentUser = JSON.parse(currentUserData)

    if (authMode === "server") {
      try {
        const response = await fetch("get_user_info.php")
        const data = await response.json()

        if (data.success) {
          currentUser = data.user
          localStorage.setItem("currentUser", JSON.stringify(currentUser))
        }
      } catch (error) {
        console.warn("Server not available, using cached data:", error)
      }
    }

    updateUserInterface()
    loadProfileData()
  } catch (error) {
    console.error("Ошибка авторизации:", error)
    window.location.href = "login.html"
  }
}

// Обновление интерфейса
function updateUserInterface() {
  if (currentUser) {
    const userProfile = document.getElementById("userProfile")
    userProfile.innerHTML = `
      <div class="user-name">${currentUser.full_name}</div>
      <div class="user-icon">${getUserIcon(currentUser.role)}</div>
    `
    userProfile.style.cursor = "pointer"
    userProfile.title = "Нажмите для выхода"
    userProfile.addEventListener("click", handleLogout)

    // Показываем ссылку на управление пользователями для администраторов
    const usersLink = document.getElementById("usersLink")
    if (usersLink && currentUser.role === "admin") {
      usersLink.style.display = "block"
    }
  }
}

// Загрузка данных профиля
async function loadProfileData() {
  if (currentUser.role === "student") {
    showStudentProfile()
    await loadUserReports()
  } else {
    showTeacherProfile()
    await loadGroups()
  }

  document.getElementById("loadingContainer").style.display = "none"
  document.getElementById("mainContent").style.display = "block"
}

// Показ профиля студента
function showStudentProfile() {
  document.getElementById("studentProfile").style.display = "block"
  document.getElementById("teacherProfile").style.display = "none"

  // Заполняем информацию о профиле
  document.getElementById("profileTitle").textContent = `Профиль: ${currentUser.full_name}`

  // Добавляем краткую информацию под ФИО
  addProfileSummaryUnderName()

  const profileDetails = document.getElementById("profileDetails")
  profileDetails.innerHTML = `
    <div class="profile-detail">
      <div class="profile-detail-label">Email</div>
      <div class="profile-detail-value">${currentUser.email}</div>
    </div>
    <div class="profile-detail">
      <div class="profile-detail-label">Роль</div>
      <div class="profile-detail-value">Студент</div>
    </div>
    ${
      currentUser.group_number
        ? `
      <div class="profile-detail">
        <div class="profile-detail-label">Группа</div>
        <div class="profile-detail-value">${currentUser.group_number}</div>
      </div>
    `
        : ""
    }
    ${
      currentUser.phone
        ? `
      <div class="profile-detail">
        <div class="profile-detail-label">Телефон</div>
        <div class="profile-detail-value">${currentUser.phone}</div>
      </div>
    `
        : ""
    }
  `

  // Добавляем статистику
  // addQuickActions()
}

// Добавление краткой информации под ФИО
function addProfileSummaryUnderName() {
  // Подсчитываем базовую статистику
  const totalReports = userReports.length
  const lastActivity =
    userReports.length > 0 ? formatDateTime(userReports[userReports.length - 1].uploaded_at) : "Нет активности"

  // Находим элемент с заголовком профиля и добавляем информацию после него
  const profileTitle = document.getElementById("profileTitle")

  // Удаляем предыдущую информацию, если она есть
  const existingSummary = document.querySelector(".profile-summary-inline")
  if (existingSummary) {
    existingSummary.remove()
  }

  // Создаем элемент с краткой информацией
  const summaryElement = document.createElement("p")
  summaryElement.className = "profile-summary-inline"
  summaryElement.innerHTML = `Загружено отчетов: ${totalReports} • Последняя активность: ${lastActivity}`

  // Вставляем после заголовка
  profileTitle.insertAdjacentElement("afterend", summaryElement)
}

// Показ профиля преподавателя/администратора
function showTeacherProfile() {
  document.getElementById("studentProfile").style.display = "none"
  document.getElementById("teacherProfile").style.display = "block"
}

// Загрузка отчетов пользователя
async function loadUserReports(userId = null) {
  const targetUserId = userId || currentUser.id
  const authMode = localStorage.getItem("authMode") || "demo"

  try {
    if (authMode === "server") {
      const response = await fetch(`reports_api.php?action=list&user_id=${targetUserId}`)
      const data = await response.json()

      if (data.success) {
        userReports = data.reports
        if (currentUser.role === "student") {
          addProfileSummaryUnderName() // Обновляем статистику после загрузки отчетов
        }
        renderReports(targetUserId === currentUser.id ? "reportsGrid" : "selectedStudentReports")
        return
      }
    }
  } catch (error) {
    console.warn("Server not available, using demo data:", error)
  }

  // Демо-данные
  loadDemoReports(targetUserId)
  if (currentUser.role === "student") {
    addProfileSummaryUnderName() // Обновляем статистику после загрузки демо-данных
  }
  renderReports(targetUserId === currentUser.id ? "reportsGrid" : "selectedStudentReports")
}

// Загрузка демо-отчетов
function loadDemoReports(userId) {
  const savedReports = localStorage.getItem("demo_reports")

  if (savedReports) {
    try {
      const allReports = JSON.parse(savedReports)
      userReports = allReports.filter((r) => r.user_id === userId)
      return
    } catch (error) {
      console.warn("Error parsing saved reports:", error)
    }
  }

  // Базовые демо-данные
  const allReports = [
    {
      id: 1,
      user_id: 4, // Сидоров
      title: "Отчет по учебной практике - Веб-разработка",
      description: "Отчет по прохождению учебной практики в области веб-разработки",
      report_type: "educational",
      file_name: "up_report_sidorov.docx",
      file_path: "/uploads/reports/up_report_sidorov.docx",
      file_size: 156789,
      mime_type: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
      status: "uploaded",
      uploaded_at: "2025-06-20 14:30:00",
    },
    {
      id: 2,
      user_id: 5, // Козлова
      title: "Отчет по производственной практике",
      description: "Отчет по производственной практике в ООО ТехКомпани",
      report_type: "production",
      file_name: "pp_report_kozlova.pdf",
      file_path: "/uploads/reports/pp_report_kozlova.pdf",
      file_size: 234567,
      mime_type: "application/pdf",
      status: "reviewed",
      reviewed_at: "2025-06-21 10:15:00",
      review_comment: "Хороший отчет, но нужно добавить больше деталей о выполненных задачах.",
      uploaded_at: "2025-06-19 16:45:00",
    },
  ]

  userReports = allReports.filter((r) => r.user_id === userId)
  localStorage.setItem("demo_reports", JSON.stringify(allReports))
}

// Отрисовка отчетов
function renderReports(containerId) {
  const container = document.getElementById(containerId)

  if (userReports.length === 0) {
    container.innerHTML = `
      <div style="text-align: center; padding: 40px; color: #6b7280;">
        <p>Отчеты не найдены</p>
      </div>
    `
    return
  }

  container.innerHTML = userReports.map((report) => createReportCard(report)).join("")
}

// Создание карточки отчета
function createReportCard(report) {
  const isOwner = report.user_id === currentUser.id
  const canReview = currentUser.role === "teacher" || currentUser.role === "admin"

  return `
    <div class="report-card">
      <div class="report-card-header">
        <div>
          <h3 class="report-title">${report.title}</h3>
          <span class="report-type ${report.report_type}">
            ${report.report_type === "educational" ? "Учебная практика" : "Производственная практика"}
          </span>
        </div>
        <span class="report-status ${report.status}">${getStatusDisplayName(report.status)}</span>
      </div>
      
      ${report.description ? `<p class="report-description">${report.description}</p>` : ""}
      
      <div class="report-meta">
        <span>Размер: ${formatFileSize(report.file_size)}</span>
        <span>Загружено: ${formatDateTime(report.uploaded_at)}</span>
      </div>
      
      ${
        report.review_comment
          ? `
        <div style="background: #f0fdf4; border: 1px solid #bbf7d0; border-radius: 6px; padding: 12px; margin-bottom: 16px;">
          <strong style="color: #166534; font-size: 12px;">Комментарий преподавателя:</strong>
          <p style="color: #166534; font-size: 14px; margin: 4px 0 0 0;">${report.review_comment}</p>
        </div>
      `
          : ""
      }
      
      <div class="report-actions">
        <button class="btn btn-outline btn-sm" onclick="downloadReport(${report.id})">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
            <polyline points="7,10 12,15 17,10"></polyline>
            <line x1="12" y1="15" x2="12" y2="3"></line>
          </svg>
          Скачать
        </button>
        ${
          canReview && !isOwner
            ? `
          <button class="btn btn-primary btn-sm" onclick="showReviewModal(${report.id})">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
              <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
            </svg>
            Проверить
          </button>
        `
            : ""
        }
        ${
          isOwner
            ? `
          <button class="btn btn-danger btn-sm" onclick="deleteReport(${report.id})">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <polyline points="3,6 5,6 21,6"></polyline>
              <path d="M19,6v14a2,2,0,0,1-2,2H7a2,2,0,0,1-2-2V6m3,0V4a2,2,0,0,1,2-2h4a2,2,0,0,1,2,2V6"></path>
            </svg>
            Удалить
          </button>
        `
            : ""
        }
      </div>
    </div>
  `
}

// Загрузка групп
async function loadGroups() {
  const authMode = localStorage.getItem("authMode") || "demo"

  try {
    if (authMode === "server") {
      const response = await fetch("reports_api.php?action=groups")
      const data = await response.json()

      if (data.success) {
        groups = data.groups
        renderGroups()
        return
      }
    }
  } catch (error) {
    console.warn("Server not available, using demo data:", error)
  }

  // Демо-данные групп
  groups = [
    { group_number: "ИС-21-1", student_count: 2 },
    { group_number: "ПР-21-2", student_count: 1 },
    { group_number: "ИС-22-1", student_count: 0 },
  ]

  renderGroups()
}

// Отрисовка групп
function renderGroups() {
  const container = document.getElementById("groupsGrid")

  container.innerHTML = groups
    .map(
      (group) => `
    <div class="group-card" onclick="selectGroup('${group.group_number}')">
      <div class="group-name">${group.group_number}</div>
      <div class="group-count">${group.student_count} студентов</div>
    </div>
  `,
    )
    .join("")
}

// Выбор группы
async function selectGroup(groupNumber) {
  selectedGroup = groupNumber
  selectedStudent = null

  // Обновляем UI
  document.querySelectorAll(".group-card").forEach((card) => card.classList.remove("selected"))
  event.target.closest(".group-card").classList.add("selected")

  document.getElementById("selectedGroupName").textContent = groupNumber
  document.getElementById("studentsSection").style.display = "block"
  document.getElementById("studentReportsSection").style.display = "none"

  await loadStudents(groupNumber)
}

// Загрузка студентов группы
async function loadStudents(groupNumber) {
  const authMode = localStorage.getItem("authMode") || "demo"

  try {
    if (authMode === "server") {
      const response = await fetch(`reports_api.php?action=students&group=${groupNumber}`)
      const data = await response.json()

      if (data.success) {
        students = data.students
        renderStudents()
        return
      }
    }
  } catch (error) {
    console.warn("Server not available, using demo data:", error)
  }

  // Демо-данные студентов
  const allStudents = [
    {
      id: 4,
      username: "sidorov_student",
      email: "sidorov@student.luberetsky-college.ru",
      first_name: "Алексей",
      last_name: "Сидоров",
      middle_name: "Владимирович",
      group_number: "ИС-21-1",
      reports_count: 1,
    },
    {
      id: 5,
      username: "kozlova_student",
      email: "kozlova@student.luberetsky-college.ru",
      first_name: "Анна",
      last_name: "Козлова",
      middle_name: "Дмитриевна",
      group_number: "ИС-21-1",
      reports_count: 1,
    },
    {
      id: 6,
      username: "volkov_student",
      email: "volkov@student.luberetsky-college.ru",
      first_name: "Дмитрий",
      last_name: "Волков",
      middle_name: "Александрович",
      group_number: "ПР-21-2",
      reports_count: 0,
    },
  ]

  students = allStudents.filter((s) => s.group_number === groupNumber)
  renderStudents()
}

// Отрисовка студентов
function renderStudents() {
  const container = document.getElementById("studentsList")

  if (students.length === 0) {
    container.innerHTML = `
      <div style="text-align: center; padding: 40px; color: #6b7280;">
        <p>Студенты в группе не найдены</p>
      </div>
    `
    return
  }

  container.innerHTML = students
    .map(
      (student) => `
    <div class="student-card" onclick="selectStudent(${student.id})">
      <div class="student-name">${student.last_name} ${student.first_name} ${student.middle_name || ""}</div>
      <div class="student-email">${student.email}</div>
      <div class="student-reports-count">${student.reports_count} отчетов</div>
    </div>
  `,
    )
    .join("")
}

// Выбор студента
async function selectStudent(studentId) {
  selectedStudent = students.find((s) => s.id === studentId)

  // Обновляем UI
  document.querySelectorAll(".student-card").forEach((card) => card.classList.remove("selected"))
  event.target.closest(".student-card").classList.add("selected")

  const fullName = `${selectedStudent.last_name} ${selectedStudent.first_name} ${selectedStudent.middle_name || ""}`
  document.getElementById("selectedStudentName").textContent = fullName
  document.getElementById("selectedStudentInfo").innerHTML = `
    <span>Email: ${selectedStudent.email}</span>
    <span>Группа: ${selectedStudent.group_number}</span>
  `

  document.getElementById("studentReportsSection").style.display = "block"

  await loadUserReports(studentId)
}

// Инициализация обработчиков событий
function initializeEventListeners() {
  // Форма загрузки отчета
  document.getElementById("uploadForm").addEventListener("submit", handleUploadReport)

  // Форма проверки отчета
  document.getElementById("reviewForm").addEventListener("submit", handleReviewReport)

  // Обработка файлов
  const fileInput = document.getElementById("reportFile")
  const uploadArea = document.getElementById("fileUploadArea")

  fileInput.addEventListener("change", handleFileSelect)

  // Drag & Drop
  uploadArea.addEventListener("dragover", (e) => {
    e.preventDefault()
    uploadArea.classList.add("dragover")
  })

  uploadArea.addEventListener("dragleave", () => {
    uploadArea.classList.remove("dragover")
  })

  uploadArea.addEventListener("drop", (e) => {
    e.preventDefault()
    uploadArea.classList.remove("dragover")
    const files = e.dataTransfer.files
    if (files.length > 0) {
      fileInput.files = files
      handleFileSelect({ target: fileInput })
    }
  })

  // Закрытие модальных окон
  document.querySelectorAll(".modal").forEach((modal) => {
    modal.addEventListener("click", function (e) {
      if (e.target === this) {
        this.classList.remove("show")
        this.style.display = "none"
      }
    })
  })
}

// Обработка выбора файла
function handleFileSelect(e) {
  const file = e.target.files[0]
  const fileInfo = document.getElementById("fileInfo")

  if (file) {
    // Проверка размера файла (10 МБ)
    if (file.size > 10 * 1024 * 1024) {
      showNotification("error", "Ошибка", "Размер файла не должен превышать 10 МБ")
      e.target.value = ""
      fileInfo.style.display = "none"
      return
    }

    // Проверка типа файла
    const allowedTypes = [
      "application/msword",
      "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
      "application/pdf",
    ]

    if (!allowedTypes.includes(file.type)) {
      showNotification("error", "Ошибка", "Поддерживаются только файлы DOC, DOCX и PDF")
      e.target.value = ""
      fileInfo.style.display = "none"
      return
    }

    // Показываем информацию о файле
    fileInfo.innerHTML = `
      <strong>Выбранный файл:</strong> ${file.name}<br>
      <strong>Размер:</strong> ${formatFileSize(file.size)}<br>
      <strong>Тип:</strong> ${file.type}
    `
    fileInfo.style.display = "block"
  } else {
    fileInfo.style.display = "none"
  }
}

// Показ модального окна загрузки
function showUploadModal() {
  document.getElementById("uploadForm").reset()
  document.getElementById("fileInfo").style.display = "none"
  showModal("uploadModal")
}

// Обработка загрузки отчета
async function handleUploadReport(e) {
  e.preventDefault()

  const formData = new FormData(e.target)
  formData.append("user_id", currentUser.id)

  try {
    const authMode = localStorage.getItem("authMode") || "demo"

    if (authMode === "server") {
      const response = await fetch("reports_api.php?action=upload", {
        method: "POST",
        body: formData,
      })

      const data = await response.json()

      if (data.success) {
        showNotification("success", "Успешно", "Отчет загружен")
        closeUploadModal()
        loadUserReports()
      } else {
        showNotification("error", "Ошибка", data.message || "Не удалось загрузить отчет")
      }
    } else {
      // Демо-режим
      const file = formData.get("file")
      const newReport = {
        id: Date.now(),
        user_id: currentUser.id,
        title: formData.get("title"),
        description: formData.get("description"),
        report_type: formData.get("report_type"),
        file_name: file.name,
        file_path: `/uploads/reports/${file.name}`,
        file_size: file.size,
        mime_type: file.type,
        status: "uploaded",
        uploaded_at: new Date().toISOString().slice(0, 19).replace("T", " "),
      }

      // Сохраняем в localStorage
      const savedReports = localStorage.getItem("demo_reports")
      const allReports = savedReports ? JSON.parse(savedReports) : []
      allReports.push(newReport)
      localStorage.setItem("demo_reports", JSON.stringify(allReports))

      userReports.push(newReport)
      renderReports("reportsGrid")
      addProfileSummaryUnderName() // Обновляем статистику
      closeUploadModal()
      showNotification("success", "Успешно", "Отчет загружен (демо-режим)")
    }
  } catch (error) {
    console.error("Ошибка загрузки отчета:", error)
    showNotification("error", "Ошибка", "Не удалось загрузить отчет")
  }
}

// Показ модального окна проверки
function showReviewModal(reportId) {
  const report = userReports.find((r) => r.id === reportId)
  if (!report) return

  document.getElementById("reviewReportId").value = reportId
  document.getElementById("reviewStatus").value = report.status
  document.getElementById("reviewComment").value = report.review_comment || ""

  document.getElementById("reviewReportInfo").innerHTML = `
    <h4>${report.title}</h4>
    <p><strong>Тип:</strong> ${
      report.report_type === "educational" ? "Учебная практика" : "Производственная практика"
    }</p>
    <p><strong>Файл:</strong> ${report.file_name}</p>
    <p><strong>Загружено:</strong> ${formatDateTime(report.uploaded_at)}</p>
    ${report.description ? `<p><strong>Описание:</strong> ${report.description}</p>` : ""}
  `

  showModal("reviewModal")
}

// Обработка проверки отчета
async function handleReviewReport(e) {
  e.preventDefault()

  const formData = new FormData(e.target)
  const reportId = Number.parseInt(formData.get("report_id"))

  try {
    const authMode = localStorage.getItem("authMode") || "demo"

    if (authMode === "server") {
      const response = await fetch("reports_api.php?action=review", {
        method: "POST",
        body: formData,
      })

      const data = await response.json()

      if (data.success) {
        showNotification("success", "Успешно", "Проверка сохранена")
        closeReviewModal()
        loadUserReports(selectedStudent.id)
      } else {
        showNotification("error", "Ошибка", data.message || "Не удалось сохранить проверку")
      }
    } else {
      // Демо-режим
      const reportIndex = userReports.findIndex((r) => r.id === reportId)
      if (reportIndex !== -1) {
        userReports[reportIndex].status = formData.get("status")
        userReports[reportIndex].review_comment = formData.get("comment")
        userReports[reportIndex].reviewed_by = currentUser.id
        userReports[reportIndex].reviewed_at = new Date().toISOString().slice(0, 19).replace("T", " ")

        // Обновляем в localStorage
        const savedReports = localStorage.getItem("demo_reports")
        const allReports = savedReports ? JSON.parse(savedReports) : []
        const globalIndex = allReports.findIndex((r) => r.id === reportId)
        if (globalIndex !== -1) {
          allReports[globalIndex] = userReports[reportIndex]
          localStorage.setItem("demo_reports", JSON.stringify(allReports))
        }

        renderReports("selectedStudentReports")
        closeReviewModal()
        showNotification("success", "Успешно", "Проверка сохранена (демо-режим)")
      }
    }
  } catch (error) {
    console.error("Ошибка проверки отчета:", error)
    showNotification("error", "Ошибка", "Не удалось сохранить проверку")
  }
}

// Скачивание отчета
function downloadReport(reportId) {
  const report = userReports.find((r) => r.id === reportId)
  if (!report) return

  // В демо-режиме просто показываем уведомление
  showNotification("info", "Скачивание", `Файл "${report.file_name}" скачан (демо-режим)`)
}

// Удаление отчета
function deleteReport(reportId) {
  const report = userReports.find((r) => r.id === reportId)
  if (!report) return

  if (confirm(`Вы уверены, что хотите удалить отчет "${report.title}"?`)) {
    const authMode = localStorage.getItem("authMode") || "demo"

    if (authMode === "server") {
      fetch(`reports_api.php?action=delete&id=${reportId}`, { method: "POST" })
        .then((response) => response.json())
        .then((data) => {
          if (data.success) {
            showNotification("success", "Успешно", "Отчет удален")
            loadUserReports()
          } else {
            showNotification("error", "Ошибка", data.message || "Не удалось удалить отчет")
          }
        })
        .catch((error) => {
          console.error("Ошибка удаления:", error)
          showNotification("error", "Ошибка", "Не удалось удалить отчет")
        })
    } else {
      // Демо-режим
      userReports = userReports.filter((r) => r.id !== reportId)

      // Обновляем в localStorage
      const savedReports = localStorage.getItem("demo_reports")
      const allReports = savedReports ? JSON.parse(savedReports) : []
      const updatedReports = allReports.filter((r) => r.id !== reportId)
      localStorage.setItem("demo_reports", JSON.stringify(updatedReports))

      renderReports("reportsGrid")
      addProfileSummaryUnderName() // Обновляем статистику
      showNotification("success", "Успешно", "Отчет удален (демо-режим)")
    }
  }
}

// Управление модальными окнами
function showModal(modalId) {
  const modal = document.getElementById(modalId)
  modal.style.display = "flex"
  modal.classList.add("show")
}

function closeUploadModal() {
  const modal = document.getElementById("uploadModal")
  modal.classList.remove("show")
  modal.style.display = "none"
}

function closeReviewModal() {
  const modal = document.getElementById("reviewModal")
  modal.classList.remove("show")
  modal.style.display = "none"
}

// Вспомогательные функции
function getUserIcon(role) {
  const icons = {
    admin: "👑",
    teacher: "👨‍🏫",
    student: "🎓",
  }
  return icons[role] || "👤"
}

function getStatusDisplayName(status) {
  const statusNames = {
    uploaded: "Загружено",
    reviewed: "Проверено",
    approved: "Одобрено",
    rejected: "Отклонено",
  }
  return statusNames[status] || status
}

function formatFileSize(bytes) {
  if (bytes === 0) return "0 Bytes"
  const k = 1024
  const sizes = ["Bytes", "KB", "MB", "GB"]
  const i = Math.floor(Math.log(bytes) / Math.log(k))
  return Number.parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i]
}

function formatDateTime(dateString) {
  const date = new Date(dateString)
  return date.toLocaleString("ru-RU", {
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
  })
}

// Показ уведомлений
function showNotification(type, title, message) {
  const notification = document.getElementById("notification")
  const icon = document.getElementById("notificationIcon")
  const titleEl = document.getElementById("notificationTitle")
  const messageEl = document.getElementById("notificationMessage")

  notification.className = `notification ${type}`

  const icons = { success: "✓", error: "✕", info: "i" }
  icon.textContent = icons[type] || "i"

  titleEl.textContent = title
  messageEl.textContent = message

  notification.classList.add("show")

  setTimeout(() => {
    notification.classList.remove("show")
  }, 5000)
}

// Обработка выхода
function handleLogout() {
  if (confirm("Вы уверены, что хотите выйти?")) {
    const authMode = localStorage.getItem("authMode") || "demo"

    if (authMode === "server") {
      fetch("logout.php", { method: "POST" }).catch(() => {})
    }

    localStorage.removeItem("currentUser")
    localStorage.removeItem("authMode")
    window.location.href = "index.html"
  }
}
