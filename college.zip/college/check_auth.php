<?php
session_start();

function checkAuth() {
    if (!isset($_SESSION['user_id']) || !isset($_SESSION['role'])) {
        return false;
    }
    return true;
}

function requireAuth() {
    if (!checkAuth()) {
        header('Location: ../login.html');
        exit;
    }
}

function requireRole($allowedRoles) {
    requireAuth();
    
    if (!in_array($_SESSION['role'], $allowedRoles)) {
        http_response_code(403);
        die('Доступ запрещен');
    }
}

function getCurrentUser() {
    if (!checkAuth()) {
        return null;
    }
    
    return [
        'id' => $_SESSION['user_id'],
        'username' => $_SESSION['username'],
        'role' => $_SESSION['role'],
        'full_name' => $_SESSION['full_name']
    ];
}
?>
