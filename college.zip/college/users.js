// Глобальные переменные
let currentUser = null
let users = []
let currentFilter = "all"

// Инициализация при загрузке страницы
document.addEventListener("DOMContentLoaded", () => {
  checkAuth()
  loadUsers()
  initializeEventListeners()
})

// Проверка авторизации и прав доступа
async function checkAuth() {
  const currentUserData = localStorage.getItem("currentUser")
  const authMode = localStorage.getItem("authMode") || "demo"

  if (!currentUserData) {
    window.location.href = "login.html"
    return
  }

  try {
    currentUser = JSON.parse(currentUserData)

    // Проверяем права администратора
    if (currentUser.role !== "admin") {
      alert("Доступ запрещен. Требуются права администратора.")
      window.location.href = "dashboard.html"
      return
    }

    if (authMode === "server") {
      try {
        const response = await fetch("get_user_info.php")
        const data = await response.json()

        if (data.success) {
          currentUser = data.user
          localStorage.setItem("currentUser", JSON.stringify(currentUser))
        }
      } catch (error) {
        console.warn("Server not available, using cached data:", error)
      }
    }

    updateUserInterface()
  } catch (error) {
    console.error("Ошибка авторизации:", error)
    window.location.href = "login.html"
  }
}

// Обновление интерфейса
function updateUserInterface() {
  if (currentUser) {
    const userProfile = document.getElementById("userProfile")
    userProfile.innerHTML = `
      <div class="user-name">${currentUser.full_name}</div>
      <div class="user-icon">👑</div>
    `
    userProfile.style.cursor = "pointer"
    userProfile.title = "Нажмите для выхода"
    userProfile.addEventListener("click", handleLogout)
  }
}

// Загрузка пользователей
async function loadUsers() {
  const authMode = localStorage.getItem("authMode") || "demo"

  try {
    if (authMode === "server") {
      const response = await fetch("users_api.php?action=list")
      const data = await response.json()

      if (data.success) {
        users = data.users
        renderUsers()
        return
      }
    }
  } catch (error) {
    console.warn("Server not available, using demo data:", error)
  }

  // Используем демо-данные
  loadDemoUsers()
  renderUsers()

  // Скрываем загрузку и показываем контент
  document.getElementById("loadingContainer").style.display = "none"
  document.getElementById("mainContent").style.display = "block"
}

// Загрузка демо-пользователей
function loadDemoUsers() {
  const savedUsers = localStorage.getItem("demo_users")

  if (savedUsers) {
    try {
      users = JSON.parse(savedUsers)
      return
    } catch (error) {
      console.warn("Error parsing saved users:", error)
    }
  }

  // Базовые демо-данные
  users = [
    {
      id: 1,
      username: "admin",
      email: "admin@luberetsky-college.ru",
      first_name: "Администратор",
      last_name: "Системы",
      middle_name: "Иванович",
      role_id: 1,
      role_name: "admin",
      role_description: "Администратор системы",
      group_number: null,
      phone: "+7-495-123-45-67",
      is_active: 1,
      last_login: "2025-06-22 16:30:00",
      created_at: "2025-06-22 13:50:32",
    },
    {
      id: 2,
      username: "ivanov_teacher",
      email: "ivanov@luberetsky-college.ru",
      first_name: "Иван",
      last_name: "Иванов",
      middle_name: "Петрович",
      role_id: 2,
      role_name: "teacher",
      role_description: "Преподаватель",
      group_number: null,
      phone: "+7-495-234-56-78",
      is_active: 1,
      last_login: "2025-06-21 14:20:00",
      created_at: "2025-06-22 13:50:32",
    },
    {
      id: 4,
      username: "sidorov_student",
      email: "sidorov@student.luberetsky-college.ru",
      first_name: "Алексей",
      last_name: "Сидоров",
      middle_name: "Владимирович",
      role_id: 3,
      role_name: "student",
      role_description: "Студент",
      group_number: "ИС-21-1",
      phone: "+7-916-123-45-67",
      is_active: 1,
      last_login: "2025-06-22 10:15:00",
      created_at: "2025-06-22 13:50:32",
    },
  ]

  saveUsersToStorage()
}

// Сохранение пользователей в localStorage
function saveUsersToStorage() {
  localStorage.setItem("demo_users", JSON.stringify(users))
}

// Отрисовка пользователей
function renderUsers() {
  const tbody = document.getElementById("usersTableBody")
  const filteredUsers = currentFilter === "all" ? users : users.filter((u) => u.role_name === currentFilter)

  if (filteredUsers.length === 0) {
    tbody.innerHTML =
      '<tr><td colspan="9" style="text-align: center; padding: 40px; color: #6b7280;">Пользователи не найдены</td></tr>'
    return
  }

  tbody.innerHTML = filteredUsers.map((user) => createUserRow(user)).join("")
}

// Создание строки пользователя
function createUserRow(user) {
  const fullName = `${user.last_name} ${user.first_name} ${user.middle_name || ""}`.trim()
  const statusClass = user.is_active ? "active" : "inactive"
  const statusText = user.is_active ? "Активен" : "Неактивен"
  const lastLogin = user.last_login ? formatDateTime(user.last_login) : "Никогда"

  return `
    <tr>
      <td>${user.id}</td>
      <td>${fullName}</td>
      <td>${user.username}</td>
      <td>${user.email}</td>
      <td><span class="role-badge ${user.role_name}">${getRoleDisplayName(user.role_name)}</span></td>
      <td>${user.group_number || "—"}</td>
      <td><span class="user-status ${statusClass}">${statusText}</span></td>
      <td>${lastLogin}</td>
      <td>
        <div class="action-buttons">
          <button class="btn-icon btn-edit" onclick="editUser(${user.id})" title="Редактировать">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
              <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
            </svg>
          </button>
          ${
            user.id !== currentUser.id
              ? `
            <button class="btn-icon btn-delete" onclick="deleteUser(${user.id})" title="Удалить">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <polyline points="3,6 5,6 21,6"></polyline>
                <path d="M19,6v14a2,2,0,0,1-2,2H7a2,2,0,0,1-2-2V6m3,0V4a2,2,0,0,1,2-2h4a2,2,0,0,1,2,2V6"></path>
              </svg>
            </button>
          `
              : ""
          }
        </div>
      </td>
    </tr>
  `
}

// Инициализация обработчиков событий
function initializeEventListeners() {
  // Фильтры
  document.querySelectorAll(".tab-btn").forEach((btn) => {
    btn.addEventListener("click", function () {
      document.querySelectorAll(".tab-btn").forEach((b) => b.classList.remove("active"))
      this.classList.add("active")
      currentFilter = this.dataset.role
      renderUsers()
    })
  })

  // Формы
  document.getElementById("addUserForm").addEventListener("submit", handleAddUser)
  document.getElementById("editUserForm").addEventListener("submit", handleEditUser)

  // Закрытие модальных окон
  document.querySelectorAll(".modal").forEach((modal) => {
    modal.addEventListener("click", function (e) {
      if (e.target === this) {
        this.classList.remove("show")
        this.style.display = "none"
      }
    })
  })

  // Валидация группы для студентов
  document.getElementById("addRole").addEventListener("change", toggleGroupField)
  document.getElementById("editRole").addEventListener("change", toggleGroupField)
}

// Переключение поля группы в зависимости от роли
function toggleGroupField(e) {
  const roleSelect = e.target
  const isStudent = roleSelect.value === "3"
  const groupField = roleSelect.closest("form").querySelector('input[name="group_number"]')

  if (groupField) {
    groupField.required = isStudent
    groupField.closest(".form-group").style.display = isStudent ? "block" : "none"
  }
}

// Показ модального окна добавления пользователя
function showAddUserModal() {
  document.getElementById("addUserForm").reset()
  showModal("addUserModal")
}

// Обработка добавления пользователя
async function handleAddUser(e) {
  e.preventDefault()

  const formData = new FormData(e.target)
  const userData = Object.fromEntries(formData.entries())

  // Валидация
  if (userData.password !== userData.password_confirm) {
    showNotification("error", "Ошибка", "Пароли не совпадают")
    return
  }

  if (userData.password.length < 6) {
    showNotification("error", "Ошибка", "Пароль должен содержать минимум 6 символов")
    return
  }

  if (userData.role_id === "3" && !userData.group_number) {
    showNotification("error", "Ошибка", "Для студентов обязательно указание группы")
    return
  }

  try {
    const authMode = localStorage.getItem("authMode") || "demo"

    if (authMode === "server") {
      // Серверный режим
      const response = await fetch("users_api.php?action=create", {
        method: "POST",
        body: formData,
      })

      const data = await response.json()

      if (data.success) {
        showNotification("success", "Успешно", "Пользователь добавлен")
        closeAddUserModal()
        loadUsers()
      } else {
        showNotification("error", "Ошибка", data.message || "Не удалось добавить пользователя")
      }
    } else {
      // Демо-режим
      const newId = Math.max(...users.map((u) => u.id), 0) + 1

      const newUser = {
        id: newId,
        username: userData.username,
        email: userData.email,
        first_name: userData.first_name,
        last_name: userData.last_name,
        middle_name: userData.middle_name || null,
        role_id: Number.parseInt(userData.role_id),
        role_name: getRoleNameById(userData.role_id),
        role_description: getRoleDescriptionById(userData.role_id),
        group_number: userData.group_id === "3" ? userData.group_number : null,
        phone: userData.phone || null,
        is_active: 1,
        last_login: null,
        created_at: new Date().toISOString().slice(0, 19).replace("T", " "),
      }

      users.push(newUser)
      saveUsersToStorage()
      renderUsers()
      closeAddUserModal()
      showNotification("success", "Успешно", "Пользователь добавлен (демо-режим)")
    }
  } catch (error) {
    console.error("Ошибка добавления пользователя:", error)
    showNotification("error", "Ошибка", "Не удалось добавить пользователя")
  }
}

// Редактирование пользователя
function editUser(userId) {
  const user = users.find((u) => u.id === userId)
  if (!user) return

  document.getElementById("editUserId").value = user.id
  document.getElementById("editLastName").value = user.last_name
  document.getElementById("editFirstName").value = user.first_name
  document.getElementById("editMiddleName").value = user.middle_name || ""
  document.getElementById("editUsername").value = user.username
  document.getElementById("editEmail").value = user.email
  document.getElementById("editRole").value = user.role_id
  document.getElementById("editGroupNumber").value = user.group_number || ""
  document.getElementById("editPhone").value = user.phone || ""
  document.getElementById("editIsActive").checked = user.is_active

  // Показать/скрыть поле группы
  const groupField = document.getElementById("editGroupNumber").closest(".form-group")
  groupField.style.display = user.role_id === 3 ? "block" : "none"

  showModal("editUserModal")
}

// Обработка редактирования пользователя
async function handleEditUser(e) {
  e.preventDefault()

  const formData = new FormData(e.target)
  const userData = Object.fromEntries(formData.entries())
  const userId = Number.parseInt(userData.user_id)

  try {
    const authMode = localStorage.getItem("authMode") || "demo"

    if (authMode === "server") {
      // Серверный режим
      const response = await fetch(`users_api.php?action=update&id=${userId}`, {
        method: "POST",
        body: formData,
      })

      const data = await response.json()

      if (data.success) {
        showNotification("success", "Успешно", "Пользователь обновлен")
        closeEditUserModal()
        loadUsers()
      } else {
        showNotification("error", "Ошибка", data.message || "Не удалось обновить пользователя")
      }
    } else {
      // Демо-режим
      const userIndex = users.findIndex((u) => u.id === userId)

      if (userIndex !== -1) {
        users[userIndex] = {
          ...users[userIndex],
          first_name: userData.first_name,
          last_name: userData.last_name,
          middle_name: userData.middle_name || null,
          username: userData.username,
          email: userData.email,
          role_id: Number.parseInt(userData.role_id),
          role_name: getRoleNameById(userData.role_id),
          role_description: getRoleDescriptionById(userData.role_id),
          group_number: userData.role_id === "3" ? userData.group_number : null,
          phone: userData.phone || null,
          is_active: userData.is_active ? 1 : 0,
        }

        saveUsersToStorage()
        renderUsers()
        closeEditUserModal()
        showNotification("success", "Успешно", "Пользователь обновлен (демо-режим)")
      }
    }
  } catch (error) {
    console.error("Ошибка обновления пользователя:", error)
    showNotification("error", "Ошибка", "Не удалось обновить пользователя")
  }
}

// Удаление пользователя
function deleteUser(userId) {
  const user = users.find((u) => u.id === userId)
  if (!user) return

  if (confirm(`Вы уверены, что хотите удалить пользователя "${user.last_name} ${user.first_name}"?`)) {
    const authMode = localStorage.getItem("authMode") || "demo"

    if (authMode === "server") {
      // Серверный режим - отправляем запрос на сервер
      fetch(`users_api.php?action=delete&id=${userId}`, { method: "POST" })
        .then((response) => response.json())
        .then((data) => {
          if (data.success) {
            showNotification("success", "Успешно", "Пользователь удален")
            loadUsers()
          } else {
            showNotification("error", "Ошибка", data.message || "Не удалось удалить пользователя")
          }
        })
        .catch((error) => {
          console.error("Ошибка удаления:", error)
          showNotification("error", "Ошибка", "Не удалось удалить пользователя")
        })
    } else {
      // Демо-режим
      users = users.filter((u) => u.id !== userId)
      saveUsersToStorage()
      renderUsers()
      showNotification("success", "Успешно", "Пользователь удален (демо-режим)")
    }
  }
}

// Управление модальными окнами
function showModal(modalId) {
  const modal = document.getElementById(modalId)
  modal.style.display = "flex"
  modal.classList.add("show")
}

function closeAddUserModal() {
  const modal = document.getElementById("addUserModal")
  modal.classList.remove("show")
  modal.style.display = "none"
}

function closeEditUserModal() {
  const modal = document.getElementById("editUserModal")
  modal.classList.remove("show")
  modal.style.display = "none"
}

// Вспомогательные функции
function getRoleDisplayName(role) {
  const roleNames = {
    admin: "Администратор",
    teacher: "Преподаватель",
    student: "Студент",
  }
  return roleNames[role] || role
}

function getRoleNameById(roleId) {
  const roleMap = { 1: "admin", 2: "teacher", 3: "student" }
  return roleMap[roleId] || "student"
}

function getRoleDescriptionById(roleId) {
  const roleMap = {
    1: "Администратор системы",
    2: "Преподаватель",
    3: "Студент",
  }
  return roleMap[roleId] || "Студент"
}

function formatDateTime(dateString) {
  const date = new Date(dateString)
  return date.toLocaleString("ru-RU", {
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
  })
}

// Показ уведомлений
function showNotification(type, title, message) {
  const notification = document.getElementById("notification")
  const icon = document.getElementById("notificationIcon")
  const titleEl = document.getElementById("notificationTitle")
  const messageEl = document.getElementById("notificationMessage")

  notification.className = `notification ${type}`

  const icons = { success: "✓", error: "✕", info: "i" }
  icon.textContent = icons[type] || "i"

  titleEl.textContent = title
  messageEl.textContent = message

  notification.classList.add("show")

  setTimeout(() => {
    notification.classList.remove("show")
  }, 5000)
}

// Обработка выхода
function handleLogout() {
  if (confirm("Вы уверены, что хотите выйти?")) {
    const authMode = localStorage.getItem("authMode") || "demo"

    if (authMode === "server") {
      fetch("logout.php", { method: "POST" }).catch(() => {})
    }

    localStorage.removeItem("currentUser")
    localStorage.removeItem("authMode")
    window.location.href = "index.html"
  }
}
