<?php
session_start();
require_once 'config.php';

// Добавляем CORS заголовки
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Обрабатываем preflight запросы
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

try {
    $pdo = getDBConnection();
    
    // Получаем последнюю версию инструкций
    $stmt = $pdo->prepare("
        SELECT i.content, i.updated_at, u.username as updated_by_username
        FROM instructions i
        LEFT JOIN users u ON i.updated_by = u.id
        ORDER BY i.updated_at DESC
        LIMIT 1
    ");
    $stmt->execute();
    $instructions = $stmt->fetch();
    
    if ($instructions) {
        echo json_encode([
            'success' => true,
            'content' => $instructions['content'],
            'updated_at' => $instructions['updated_at'],
            'updated_by' => $instructions['updated_by_username']
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'Инструкции не найдены'
        ]);
    }

} catch (PDOException $e) {
    error_log("Database error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Ошибка сервера']);
} catch (Exception $e) {
    error_log("General error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Общая ошибка: ' . $e->getMessage()]);
}
?>
