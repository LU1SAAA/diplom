<?php
// Конфигурация базы данных
define('DB_HOST', 'localhost');
define('DB_NAME', 'luberetsky_college');
define('DB_USER', 'root'); // Измените на ваше имя пользователя
define('DB_PASS', ''); // Измените на ваш пароль
define('DB_CHARSET', 'utf8mb4');

// Создание подключения к базе данных
function getDBConnection() {
    try {
        $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;
        $pdo = new PDO($dsn, DB_USER, DB_PASS);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
        return $pdo;
    } catch (PDOException $e) {
        die("Ошибка подключения к базе данных: " . $e->getMessage());
    }
}

// Функция для безопасного выполнения запросов
function executeQuery($query, $params = []) {
    $pdo = getDBConnection();
    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    return $stmt;
}
?>
