<?php
session_start();
require_once 'config.php';
require_once 'check_auth.php';

header('Content-Type: application/json; charset=utf-8');

// Проверяем авторизацию и права администратора
requireRole(['admin']);

$action = $_GET['action'] ?? 'list';
$method = $_SERVER['REQUEST_METHOD'];

try {
    $pdo = getDBConnection();
    
    switch ($action) {
        case 'list':
            handleListUsers($pdo);
            break;
            
        case 'create':
            handleCreateUser($pdo);
            break;
            
        case 'update':
            handleUpdateUser($pdo);
            break;
            
        case 'delete':
            handleDeleteUser($pdo);
            break;
            
        default:
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => 'Неизвестное действие']);
    }
    
} catch (Exception $e) {
    error_log("Users API error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Ошибка сервера']);
}

function handleListUsers($pdo) {
    $stmt = $pdo->prepare("
        SELECT u.*, r.role_name, r.role_description 
        FROM users u 
        JOIN roles r ON u.role_id = r.id 
        ORDER BY u.created_at DESC
    ");
    $stmt->execute();
    $users = $stmt->fetchAll();
    
    echo json_encode([
        'success' => true,
        'users' => $users
    ]);
}

function handleCreateUser($pdo) {
    $username = $_POST['username'] ?? '';
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';
    $first_name = $_POST['first_name'] ?? '';
    $last_name = $_POST['last_name'] ?? '';
    $middle_name = $_POST['middle_name'] ?? null;
    $role_id = $_POST['role_id'] ?? '';
    $group_number = $_POST['group_number'] ?? null;
    $phone = $_POST['phone'] ?? null;
    
    // Валидация
    if (empty($username) || empty($email) || empty($password) || empty($first_name) || empty($last_name) || empty($role_id)) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Заполните все обязательные поля']);
        return;
    }
    
    if (strlen($password) < 6) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Пароль должен содержать минимум 6 символов']);
        return;
    }
    
    // Проверяем уникальность username и email
    $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
    $stmt->execute([$username, $email]);
    if ($stmt->fetch()) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Пользователь с таким логином или email уже существует']);
        return;
    }
    
    // Хешируем пароль
    $password_hash = password_hash($password, PASSWORD_DEFAULT);
    
    // Создаем пользователя
    $stmt = $pdo->prepare("
        INSERT INTO users (username, email, password_hash, first_name, last_name, middle_name, role_id, group_number, phone) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    ");
    
    $stmt->execute([
        $username, $email, $password_hash, $first_name, $last_name, $middle_name, $role_id, $group_number, $phone
    ]);
    
    echo json_encode(['success' => true, 'message' => 'Пользователь успешно создан']);
}

function handleUpdateUser($pdo) {
    $user_id = $_GET['id'] ?? 0;
    $username = $_POST['username'] ?? '';
    $email = $_POST['email'] ?? '';
    $first_name = $_POST['first_name'] ?? '';
    $last_name = $_POST['last_name'] ?? '';
    $middle_name = $_POST['middle_name'] ?? null;
    $role_id = $_POST['role_id'] ?? '';
    $group_number = $_POST['group_number'] ?? null;
    $phone = $_POST['phone'] ?? null;
    $is_active = isset($_POST['is_active']) ? 1 : 0;
    
    // Валидация
    if (empty($username) || empty($email) || empty($first_name) || empty($last_name) || empty($role_id)) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Заполните все обязательные поля']);
        return;
    }
    
    // Проверяем уникальность username и email (исключая текущего пользователя)
    $stmt = $pdo->prepare("SELECT id FROM users WHERE (username = ? OR email = ?) AND id != ?");
    $stmt->execute([$username, $email, $user_id]);
    if ($stmt->fetch()) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Пользователь с таким логином или email уже существует']);
        return;
    }
    
    // Обновляем пользователя
    $stmt = $pdo->prepare("
        UPDATE users 
        SET username = ?, email = ?, first_name = ?, last_name = ?, middle_name = ?, 
            role_id = ?, group_number = ?, phone = ?, is_active = ?
        WHERE id = ?
    ");
    
    $stmt->execute([
        $username, $email, $first_name, $last_name, $middle_name, 
        $role_id, $group_number, $phone, $is_active, $user_id
    ]);
    
    echo json_encode(['success' => true, 'message' => 'Пользователь успешно обновлен']);
}

function handleDeleteUser($pdo) {
    $user_id = $_GET['id'] ?? 0;
    
    // Проверяем, что пользователь не удаляет сам себя
    if ($user_id == $_SESSION['user_id']) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Нельзя удалить самого себя']);
        return;
    }
    
    // Помечаем как неактивный вместо удаления
    $stmt = $pdo->prepare("UPDATE users SET is_active = 0 WHERE id = ?");
    $stmt->execute([$user_id]);
    
    echo json_encode(['success' => true, 'message' => 'Пользователь успешно удален']);
}
?>
