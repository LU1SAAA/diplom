<?php
session_start();
require_once 'config.php';
require_once 'check_auth.php';

header('Content-Type: application/json; charset=utf-8');

// Проверяем авторизацию
requireAuth();

$action = $_GET['action'] ?? 'list';
$method = $_SERVER['REQUEST_METHOD'];

try {
    $pdo = getDBConnection();
    
    switch ($action) {
        case 'list':
            handleListReports($pdo);
            break;
            
        case 'upload':
            requireRole(['student']);
            handleUploadReport($pdo);
            break;
            
        case 'review':
            requireRole(['teacher', 'admin']);
            handleReviewReport($pdo);
            break;
            
        case 'delete':
            handleDeleteReport($pdo);
            break;
            
        case 'groups':
            requireRole(['teacher', 'admin']);
            handleListGroups($pdo);
            break;
            
        case 'students':
            requireRole(['teacher', 'admin']);
            handleListStudents($pdo);
            break;
            
        default:
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => 'Неизвестное действие']);
    }
    
} catch (Exception $e) {
    error_log("Reports API error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Ошибка сервера']);
}

function handleListReports($pdo) {
    $user_id = $_GET['user_id'] ?? $_SESSION['user_id'];
    
    // Проверяем права доступа
    if ($user_id != $_SESSION['user_id'] && !in_array($_SESSION['role'], ['teacher', 'admin'])) {
        http_response_code(403);
        echo json_encode(['success' => false, 'message' => 'Доступ запрещен']);
        return;
    }
    
    $stmt = $pdo->prepare("
        SELECT sr.*, u.first_name, u.last_name, u.middle_name,
               reviewer.first_name as reviewer_first_name, 
               reviewer.last_name as reviewer_last_name
        FROM student_reports sr
        JOIN users u ON sr.user_id = u.id
        LEFT JOIN users reviewer ON sr.reviewed_by = reviewer.id
        WHERE sr.user_id = ?
        ORDER BY sr.uploaded_at DESC
    ");
    $stmt->execute([$user_id]);
    $reports = $stmt->fetchAll();
    
    echo json_encode([
        'success' => true,
        'reports' => $reports
    ]);
}

function handleUploadReport($pdo) {
    $user_id = $_POST['user_id'] ?? $_SESSION['user_id'];
    $title = $_POST['title'] ?? '';
    $description = $_POST['description'] ?? '';
    $report_type = $_POST['report_type'] ?? '';
    
    // Проверяем, что студент загружает только свои отчеты
    if ($user_id != $_SESSION['user_id'] && $_SESSION['role'] !== 'admin') {
        http_response_code(403);
        echo json_encode(['success' => false, 'message' => 'Доступ запрещен']);
        return;
    }
    
    // Валидация
    if (empty($title) || empty($report_type)) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Заполните все обязательные поля']);
        return;
    }
    
    // Обработка загруженного файла
    if (!isset($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Файл не загружен']);
        return;
    }
    
    $file = $_FILES['file'];
    $uploadDir = '../uploads/reports/';
    
    // Создаем директорию если не существует
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0755, true);
    }
    
    // Генерируем уникальное имя файла
    $fileExtension = pathinfo($file['name'], PATHINFO_EXTENSION);
    $fileName = uniqid() . '_' . time() . '.' . $fileExtension;
    $filePath = $uploadDir . $fileName;
    
    // Проверяем тип файла
    $allowedTypes = [
        'application/msword',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'application/pdf'
    ];
    
    if (!in_array($file['type'], $allowedTypes)) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Неподдерживаемый тип файла']);
        return;
    }
    
    // Проверяем размер файла (10 МБ)
    if ($file['size'] > 10 * 1024 * 1024) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Размер файла превышает 10 МБ']);
        return;
    }
    
    // Перемещаем файл
    if (!move_uploaded_file($file['tmp_name'], $filePath)) {
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Ошибка загрузки файла']);
        return;
    }
    
    // Сохраняем в базу данных
    $stmt = $pdo->prepare("
        INSERT INTO student_reports 
        (user_id, title, description, report_type, file_name, file_path, file_size, mime_type) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    ");
    
    $stmt->execute([
        $user_id, $title, $description, $report_type, 
        $file['name'], '/uploads/reports/' . $fileName, 
        $file['size'], $file['type']
    ]);
    
    echo json_encode(['success' => true, 'message' => 'Отчет успешно загружен']);
}

function handleReviewReport($pdo) {
    $report_id = $_POST['report_id'] ?? 0;
    $status = $_POST['status'] ?? '';
    $comment = $_POST['comment'] ?? '';
    
    // Валидация
    if (empty($status)) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Укажите статус проверки']);
        return;
    }
    
    $allowedStatuses = ['reviewed', 'approved', 'rejected'];
    if (!in_array($status, $allowedStatuses)) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Неверный статус']);
        return;
    }
    
    // Обновляем отчет
    $stmt = $pdo->prepare("
        UPDATE student_reports 
        SET status = ?, review_comment = ?, reviewed_by = ?, reviewed_at = NOW()
        WHERE id = ?
    ");
    
    $stmt->execute([$status, $comment, $_SESSION['user_id'], $report_id]);
    
    echo json_encode(['success' => true, 'message' => 'Проверка сохранена']);
}

function handleDeleteReport($pdo) {
    $report_id = $_GET['id'] ?? 0;
    
    // Получаем информацию об отчете
    $stmt = $pdo->prepare("SELECT user_id, file_path FROM student_reports WHERE id = ?");
    $stmt->execute([$report_id]);
    $report = $stmt->fetch();
    
    if (!$report) {
        http_response_code(404);
        echo json_encode(['success' => false, 'message' => 'Отчет не найден']);
        return;
    }
    
    // Проверяем права доступа
    if ($report['user_id'] != $_SESSION['user_id'] && $_SESSION['role'] !== 'admin') {
        http_response_code(403);
        echo json_encode(['success' => false, 'message' => 'Доступ запрещен']);
        return;
    }
    
    // Удаляем файл
    $filePath = '../' . ltrim($report['file_path'], '/');
    if (file_exists($filePath)) {
        unlink($filePath);
    }
    
    // Удаляем запись из базы данных
    $stmt = $pdo->prepare("DELETE FROM student_reports WHERE id = ?");
    $stmt->execute([$report_id]);
    
    echo json_encode(['success' => true, 'message' => 'Отчет удален']);
}

function handleListGroups($pdo) {
    $stmt = $pdo->prepare("
        SELECT group_number, COUNT(*) as student_count 
        FROM users 
        WHERE role_id = 3 AND group_number IS NOT NULL AND is_active = 1
        GROUP BY group_number 
        ORDER BY group_number
    ");
    $stmt->execute();
    $groups = $stmt->fetchAll();
    
    echo json_encode([
        'success' => true,
        'groups' => $groups
    ]);
}

function handleListStudents($pdo) {
    $group = $_GET['group'] ?? '';
    
    if (empty($group)) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Укажите группу']);
        return;
    }
    
    $stmt = $pdo->prepare("
        SELECT u.*, 
               (SELECT COUNT(*) FROM student_reports sr WHERE sr.user_id = u.id) as reports_count
        FROM users u
        WHERE u.role_id = 3 AND u.group_number = ? AND u.is_active = 1
        ORDER BY u.last_name, u.first_name
    ");
    $stmt->execute([$group]);
    $students = $stmt->fetchAll();
    
    echo json_encode([
        'success' => true,
        'students' => $students
    ]);
}
?>
