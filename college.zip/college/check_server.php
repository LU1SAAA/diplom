<?php
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Простая проверка доступности сервера
echo json_encode([
    'success' => true,
    'message' => 'Сервер доступен',
    'timestamp' => date('Y-m-d H:i:s')
]);
?>
