<?php
session_start();
require_once 'config.php';
require_once 'check_auth.php';

header('Content-Type: application/json; charset=utf-8');

$action = $_GET['action'] ?? 'list';
$method = $_SERVER['REQUEST_METHOD'];

try {
    $pdo = getDBConnection();
    
    switch ($action) {
        case 'list':
            handleListTemplates($pdo);
            break;
            
        case 'create':
            requireRole(['admin']);
            handleCreateTemplate($pdo);
            break;
            
        case 'update':
            requireRole(['admin']);
            handleUpdateTemplate($pdo);
            break;
            
        case 'delete':
            requireRole(['admin']);
            handleDeleteTemplate($pdo);
            break;
            
        case 'download':
            handleDownloadTemplate($pdo);
            break;
            
        default:
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => 'Неизвестное действие']);
    }
    
} catch (Exception $e) {
    error_log("Templates API error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Ошибка сервера']);
}

function handleListTemplates($pdo) {
    $stmt = $pdo->prepare("
        SELECT dt.*, u.username as created_by_username 
        FROM document_templates dt 
        LEFT JOIN users u ON dt.created_by = u.id 
        WHERE dt.is_active = 1 
        ORDER BY dt.category, dt.title
    ");
    $stmt->execute();
    $templates = $stmt->fetchAll();
    
    echo json_encode([
        'success' => true,
        'templates' => $templates
    ]);
}

function handleCreateTemplate($pdo) {
    $title = $_POST['title'] ?? '';
    $description = $_POST['description'] ?? '';
    $category = $_POST['category'] ?? '';
    
    if (empty($title) || empty($category)) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Заполните обязательные поля']);
        return;
    }
    
    // Обработка загруженного файла
    $fileName = '';
    $filePath = '';
    $fileSize = 0;
    $mimeType = '';
    
    if (isset($_FILES['file']) && $_FILES['file']['error'] === UPLOAD_ERR_OK) {
        $uploadDir = '../templates/files/';
        $fileName = basename($_FILES['file']['name']);
        $filePath = $uploadDir . $fileName;
        $fileSize = $_FILES['file']['size'];
        $mimeType = $_FILES['file']['type'];
        
        // Создаем директорию если не существует
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0755, true);
        }
        
        if (!move_uploaded_file($_FILES['file']['tmp_name'], $filePath)) {
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => 'Ошибка загрузки файла']);
            return;
        }
        
        $filePath = '/templates/files/' . $fileName;
    }
    
    $stmt = $pdo->prepare("
        INSERT INTO document_templates 
        (title, description, category, file_name, file_path, file_size, mime_type, created_by) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    ");
    
    $stmt->execute([
        $title, $description, $category, $fileName, $filePath, $fileSize, $mimeType, $_SESSION['user_id']
    ]);
    
    echo json_encode(['success' => true, 'message' => 'Шаблон успешно создан']);
}

function handleUpdateTemplate($pdo) {
    $templateId = $_GET['id'] ?? 0;
    $title = $_POST['title'] ?? '';
    $description = $_POST['description'] ?? '';
    $category = $_POST['category'] ?? '';
    
    if (empty($title) || empty($category)) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Заполните обязательные поля']);
        return;
    }
    
    // Получаем текущую информацию о шаблоне
    $stmt = $pdo->prepare("SELECT * FROM document_templates WHERE id = ?");
    $stmt->execute([$templateId]);
    $template = $stmt->fetch();
    
    if (!$template) {
        http_response_code(404);
        echo json_encode(['success' => false, 'message' => 'Шаблон не найден']);
        return;
    }
    
    $fileName = $template['file_name'];
    $filePath = $template['file_path'];
    $fileSize = $template['file_size'];
    $mimeType = $template['mime_type'];
    
    // Обработка нового файла, если загружен
    if (isset($_FILES['file']) && $_FILES['file']['error'] === UPLOAD_ERR_OK) {
        $uploadDir = '../templates/files/';
        $fileName = basename($_FILES['file']['name']);
        $newFilePath = $uploadDir . $fileName;
        $fileSize = $_FILES['file']['size'];
        $mimeType = $_FILES['file']['type'];
        
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0755, true);
        }
        
        if (move_uploaded_file($_FILES['file']['tmp_name'], $newFilePath)) {
            // Удаляем старый файл
            if (file_exists('../' . ltrim($template['file_path'], '/'))) {
                unlink('../' . ltrim($template['file_path'], '/'));
            }
            $filePath = '/templates/files/' . $fileName;
        }
    }
    
    $stmt = $pdo->prepare("
        UPDATE document_templates 
        SET title = ?, description = ?, category = ?, file_name = ?, file_path = ?, 
            file_size = ?, mime_type = ?, updated_by = ?, updated_at = NOW()
        WHERE id = ?
    ");
    
    $stmt->execute([
        $title, $description, $category, $fileName, $filePath, 
        $fileSize, $mimeType, $_SESSION['user_id'], $templateId
    ]);
    
    echo json_encode(['success' => true, 'message' => 'Шаблон успешно обновлен']);
}

function handleDeleteTemplate($pdo) {
    $templateId = $_GET['id'] ?? 0;
    
    // Получаем информацию о файле для удаления
    $stmt = $pdo->prepare("SELECT file_path FROM document_templates WHERE id = ?");
    $stmt->execute([$templateId]);
    $template = $stmt->fetch();
    
    if ($template) {
        // Удаляем файл
        $filePath = '../' . ltrim($template['file_path'], '/');
        if (file_exists($filePath)) {
            unlink($filePath);
        }
        
        // Помечаем как неактивный вместо удаления
        $stmt = $pdo->prepare("UPDATE document_templates SET is_active = 0 WHERE id = ?");
        $stmt->execute([$templateId]);
        
        echo json_encode(['success' => true, 'message' => 'Шаблон успешно удален']);
    } else {
        http_response_code(404);
        echo json_encode(['success' => false, 'message' => 'Шаблон не найден']);
    }
}

function handleDownloadTemplate($pdo) {
    $templateId = $_GET['id'] ?? 0;
    
    // Увеличиваем счетчик скачиваний
    $stmt = $pdo->prepare("UPDATE document_templates SET download_count = download_count + 1 WHERE id = ?");
    $stmt->execute([$templateId]);
    
    echo json_encode(['success' => true, 'message' => 'Счетчик обновлен']);
}
?>
