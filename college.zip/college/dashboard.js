document.addEventListener("DOMContentLoaded", async () => {
  // Check authentication and load user data
  await checkAuthAndLoadUser()

  // Add logout functionality
  addLogoutFunctionality()

  // Add navigation functionality
  addNavigationFunctionality()
})

async function checkAuthAndLoadUser() {
  const authMode = localStorage.getItem("authMode") || "demo"
  const currentUser = localStorage.getItem("currentUser")

  if (!currentUser) {
    // Redirect to login if not authenticated
    window.location.href = "login.html"
    return
  }

  let user
  try {
    user = JSON.parse(currentUser)
  } catch (error) {
    console.error("Error parsing user data:", error)
    window.location.href = "login.html"
    return
  }

  if (authMode === "server") {
    // Try to get fresh user data from server
    try {
      const response = await fetch("get_user_info.php")

      if (response.ok) {
        const data = await response.json()
        if (data.success) {
          user = data.user
          localStorage.setItem("currentUser", JSON.stringify(user))
        } else {
          console.warn("Server authentication failed, using cached data")
        }
      } else {
        console.warn("Server not available, using cached data")
      }
    } catch (error) {
      console.warn("Server not available, using cached data:", error)
    }
  }

  // Update UI with user information
  updateUserProfile(user)
  updateUIForRole(user.role, user)
}

function updateUserProfile(user) {
  const userProfile = document.querySelector(".user-profile")

  if (userProfile) {
    // Clear existing content
    userProfile.innerHTML = ""

    // Add user icon
    const userIcon = document.createElement("div")
    userIcon.className = "user-icon"

    switch (user.role) {
      case "admin":
        userIcon.textContent = "👑"
        userIcon.title = "Администратор"
        break
      case "teacher":
        userIcon.textContent = "👨‍🏫"
        userIcon.title = "Преподаватель"
        break
      case "student":
        userIcon.textContent = "🎓"
        userIcon.title = "Студент"
        break
      default:
        userIcon.textContent = "👤"
    }

    // Add user name
    const userName = document.createElement("div")
    userName.className = "user-name"
    userName.textContent = user.full_name || user.username

    userProfile.appendChild(userIcon)
    userProfile.appendChild(userName)
  }
}

function updateUIForRole(role, user) {
  const dashboardContainer = document.querySelector(".dashboard-container")

  if (!dashboardContainer) return

  // Remove existing role notes
  const existingNotes = dashboardContainer.querySelectorAll(
    ".teacher-note, .student-note, .admin-note, .mode-indicator",
  )
  existingNotes.forEach((note) => note.remove())

  let roleNote

  switch (role) {
    case "admin":
      roleNote = document.createElement("div")
      roleNote.className = "admin-note"
      roleNote.innerHTML = `
                <p>👑 Вы вошли как администратор. У вас есть полный доступ к управлению системой.</p>
            `
      break

    case "teacher":
      roleNote = document.createElement("div")
      roleNote.className = "teacher-note"
      roleNote.innerHTML = `
                <p>👨‍🏫 Вы вошли как преподаватель. У вас есть дополнительные возможности для работы со студентами.</p>
            `
      break

    case "student":
      roleNote = document.createElement("div")
      roleNote.className = "student-note"
      const groupInfo = user.group_number ? ` (группа ${user.group_number})` : ""
      roleNote.innerHTML = `
                <p>🎓 Вы вошли как студент${groupInfo}. Используйте все возможности платформы для успешного прохождения практики.</p>
            `
      break
  }

  if (roleNote) {
    dashboardContainer.appendChild(roleNote)
  }

  // Показываем ссылку на управление пользователями для администраторов
  const usersLink = document.getElementById("usersLink")
  if (usersLink && role === "admin") {
    usersLink.style.display = "block"
  }

  // Add mode indicator
  const authMode = localStorage.getItem("authMode") || "demo"
  const modeIndicator = document.createElement("div")
  modeIndicator.className = "mode-indicator"
  modeIndicator.innerHTML = `
        <p style="background: ${
          authMode === "demo" ? "#fef3c7" : "#dcfce7"
        }; padding: 8px; border-radius: 4px; font-size: 12px; color: ${
          authMode === "demo" ? "#92400e" : "#166534"
        }; margin-top: 20px;">
            ${authMode === "demo" ? "🔧 Демо-режим" : "🌐 Серверный режим"}
        </p>
    `
  dashboardContainer.appendChild(modeIndicator)
}

function addLogoutFunctionality() {
  const userProfile = document.querySelector(".user-profile")

  if (userProfile) {
    userProfile.style.cursor = "pointer"
    userProfile.title = "Нажмите для выхода"

    userProfile.addEventListener("click", async () => {
      if (confirm("Вы уверены, что хотите выйти?")) {
        const authMode = localStorage.getItem("authMode") || "demo"

        if (authMode === "server") {
          try {
            await fetch("auth/logout.php", { method: "POST" })
          } catch (error) {
            console.warn("Server logout failed:", error)
          }
        }

        // Clear local storage
        localStorage.removeItem("currentUser")
        localStorage.removeItem("authMode")
        window.location.href = "index.html"
      }
    })
  }
}

function addNavigationFunctionality() {
  document.querySelectorAll(".nav-link").forEach((link) => {
    link.addEventListener("click", function (e) {
      if (this.getAttribute("href") === "#") {
        e.preventDefault()
        alert("Этот раздел находится в разработке")
      }
    })
  })
}
