document.addEventListener("DOMContentLoaded", () => {
  // Инициализация страницы инструкций
  initializeInstructions()

  // Проверяем роль пользователя для отображения админ-панели
  checkUserRole()

  // Загружаем сохраненные инструкции
  loadSavedInstructions()

  // Инициализация плавной прокрутки
  initializeSmoothScroll()

  // Инициализация редактирования для администратора
  initializeAdminEditing()
})

function initializeInstructions() {
  // Подсветка активного раздела при прокрутке
  const sections = document.querySelectorAll(".instruction-section")
  const sidebarLinks = document.querySelectorAll(".sidebar-link")

  function updateActiveSection() {
    let current = ""

    sections.forEach((section) => {
      const sectionTop = section.offsetTop
      const sectionHeight = section.clientHeight
      if (window.pageYOffset >= sectionTop - 200) {
        current = section.getAttribute("id")
      }
    })

    sidebarLinks.forEach((link) => {
      link.classList.remove("active")
      if (link.getAttribute("href") === "#" + current) {
        link.classList.add("active")
      }
    })
  }

  window.addEventListener("scroll", updateActiveSection)
  updateActiveSection()
}

function checkUserRole() {
  const currentUser = localStorage.getItem("currentUser")
  if (currentUser) {
    try {
      const user = JSON.parse(currentUser)
      if (user.role === "admin") {
        document.getElementById("adminControls").style.display = "block"
      }

      // Показываем ссылку на управление пользователями для администраторов
      const usersLink = document.getElementById("usersLink")
      if (usersLink && user.role === "admin") {
        usersLink.style.display = "block"
      }
    } catch (error) {
      console.error("Error parsing user data:", error)
    }
  }
}

function initializeSmoothScroll() {
  const sidebarLinks = document.querySelectorAll(".sidebar-link")

  sidebarLinks.forEach((link) => {
    link.addEventListener("click", (e) => {
      e.preventDefault()

      const targetId = link.getAttribute("href").substring(1)
      const targetElement = document.getElementById(targetId)

      if (targetElement) {
        const headerHeight = document.querySelector(".header").offsetHeight
        const navHeight = document.querySelector(".navigation").offsetHeight
        const offset = headerHeight + navHeight + 20

        const targetPosition = targetElement.offsetTop - offset

        window.scrollTo({
          top: targetPosition,
          behavior: "smooth",
        })

        // Обновляем активную ссылку
        sidebarLinks.forEach((l) => l.classList.remove("active"))
        link.classList.add("active")
      }
    })
  })
}

function initializeAdminEditing() {
  const editBtn = document.getElementById("editBtn")
  const saveBtn = document.getElementById("saveBtn")
  const cancelBtn = document.getElementById("cancelBtn")
  const contentWrapper = document.getElementById("contentWrapper")

  let originalContent = ""
  let isEditing = false

  if (editBtn) {
    editBtn.addEventListener("click", () => {
      startEditing()
    })
  }

  if (saveBtn) {
    saveBtn.addEventListener("click", () => {
      saveContent()
    })
  }

  if (cancelBtn) {
    cancelBtn.addEventListener("click", () => {
      cancelEditing()
    })
  }

  function startEditing() {
    if (isEditing) return

    originalContent = contentWrapper.innerHTML
    isEditing = true

    // Делаем контент редактируемым
    contentWrapper.contentEditable = true
    contentWrapper.classList.add("editing")

    // Переключаем кнопки
    editBtn.style.display = "none"
    saveBtn.style.display = "inline-block"
    cancelBtn.style.display = "inline-block"

    // Показываем уведомление
    showNotification("Режим редактирования активирован", "info")
  }

  function saveContent() {
    if (!isEditing) return

    const newContent = contentWrapper.innerHTML

    // Отправляем данные на сервер
    saveInstructionsToServer(newContent)
      .then(() => {
        finishEditing()
        showNotification("Инструкции успешно сохранены", "success")
      })
      .catch((error) => {
        console.error("Error saving instructions:", error)
        showNotification("Ошибка при сохранении инструкций", "error")
      })
  }

  function cancelEditing() {
    if (!isEditing) return

    // Восстанавливаем оригинальный контент
    contentWrapper.innerHTML = originalContent
    finishEditing()
    showNotification("Редактирование отменено", "info")
  }

  function finishEditing() {
    isEditing = false
    contentWrapper.contentEditable = false
    contentWrapper.classList.remove("editing")

    // Переключаем кнопки
    editBtn.style.display = "inline-block"
    saveBtn.style.display = "none"
    cancelBtn.style.display = "none"

    // Переинициализируем обработчики
    initializeSmoothScroll()
  }

  async function saveInstructionsToServer(content) {
    const authMode = localStorage.getItem("authMode") || "demo"

    if (authMode === "demo") {
      // В демо-режиме сохраняем в localStorage
      return new Promise((resolve) => {
        setTimeout(() => {
          localStorage.setItem("instructions_content", content)
          console.log("Инструкции сохранены в localStorage")
          resolve()
        }, 1000)
      })
    } else {
      // Отправляем на сервер
      const response = await fetch("save_instructions.php", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          content: content,
        }),
      })

      if (!response.ok) {
        throw new Error("Failed to save instructions")
      }

      const result = await response.json()
      console.log("Инструкции сохранены на сервере:", result.timestamp)
      return result
    }
  }
}

function showNotification(message, type = "info") {
  // Создаем уведомление
  const notification = document.createElement("div")
  notification.className = `notification ${type}-notification show`
  notification.innerHTML = `
    <div class="notification-content">
      <div class="notification-icon">${type === "success" ? "✓" : type === "error" ? "✕" : "ℹ"}</div>
      <div class="notification-text">
        <p>${message}</p>
      </div>
    </div>
  `

  document.body.appendChild(notification)

  // Автоматически скрываем через 3 секунды
  setTimeout(() => {
    notification.classList.remove("show")
    setTimeout(() => {
      document.body.removeChild(notification)
    }, 300)
  }, 3000)
}

async function loadSavedInstructions() {
  const authMode = localStorage.getItem("authMode") || "demo"

  if (authMode === "server") {
    try {
      const response = await fetch("get_instructions.php")

      if (response.ok) {
        const data = await response.json()
        if (data.success && data.content) {
          document.getElementById("contentWrapper").innerHTML = data.content
          console.log("Загружены сохраненные инструкции")

          // Переинициализируем обработчики после загрузки
          initializeSmoothScroll()
        }
      }
    } catch (error) {
      console.warn("Не удалось загрузить сохраненные инструкции:", error)
    }
  } else {
    // В демо-режиме проверяем localStorage
    const savedContent = localStorage.getItem("instructions_content")
    if (savedContent) {
      document.getElementById("contentWrapper").innerHTML = savedContent
      console.log("Загружены инструкции из localStorage")
      initializeSmoothScroll()
    }
  }
}
