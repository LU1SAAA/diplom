// Демо-данные пользователей (роль определяется по username)
const DEMO_USERS = {
  student: {
    username: "student",
    password: "password123",
    role: "student",
    full_name: "Алексей Сидоров Владимирович",
    email: "sidorov@student.luberetsky-college.ru",
    group_number: "ИС-21-1",
    id: 1,
  },
  teacher: {
    username: "teacher",
    password: "password123",
    role: "teacher",
    full_name: "Иван Иванов Петрович",
    email: "ivanov@luberetsky-college.ru",
    group_number: null,
    id: 2,
  },
  admin: {
    username: "admin",
    password: "password123",
    role: "admin",
    full_name: "Администратор Системы Иванович",
    email: "admin@luberetsky-college.ru",
    group_number: null,
    id: 3,
  },
}

document.addEventListener("DOMContentLoaded", () => {
  const loginForm = document.getElementById("loginForm")
  const successNotification = document.getElementById("successNotification")
  const errorNotification = document.getElementById("errorNotification")
  const demoModeCheckbox = document.getElementById("demoMode")
  const demoCredentials = document.getElementById("demoCredentials")

  // Проверяем, работает ли сервер
  checkServerAvailability()

  if (loginForm) {
    loginForm.addEventListener("submit", async (e) => {
      e.preventDefault()

      const usernameField = document.getElementById("username")
      const passwordField = document.getElementById("password")
      const submitBtn = document.querySelector(".submit-btn")

      // Проверяем, что все поля существуют
      if (!usernameField || !passwordField) {
        showErrorNotification("Ошибка", "Не удается найти поля формы")
        return
      }

      const username = usernameField.value.trim()
      const password = passwordField.value.trim()

      if (!username || !password) {
        showErrorNotification("Ошибка", "Заполните все поля")
        return
      }

      // Disable submit button during request
      submitBtn.disabled = true
      submitBtn.textContent = "Вход..."

      try {
        const isDemoMode = demoModeCheckbox ? demoModeCheckbox.checked : true
        let success = false
        let userData = null
        let errorMessage = ""

        if (isDemoMode) {
          // Демо-режим
          const result = authenticateDemo(username, password)
          success = result.success
          userData = result.user
          errorMessage = result.message
        } else {
          // Серверный режим
          const result = await authenticateServer(username, password)
          success = result.success
          userData = result.user
          errorMessage = result.message
        }

        if (success && userData) {
          // Store user data in localStorage
          localStorage.setItem("currentUser", JSON.stringify(userData))
          localStorage.setItem("authMode", isDemoMode ? "demo" : "server")

          // Show success notification with role info
          showSuccessNotification("Успешная авторизация!", `Добро пожаловать, ${getRoleDisplayName(userData.role)}!`)

          // Redirect to dashboard after notification
          setTimeout(() => {
            window.location.href = "dashboard.html"
          }, 2000)
        } else {
          showErrorNotification("Ошибка входа", errorMessage || "Неверные данные для входа")
        }
      } catch (error) {
        console.error("Login error:", error)
        showErrorNotification("Ошибка", "Произошла ошибка при входе в систему")
      } finally {
        // Re-enable submit button
        submitBtn.disabled = false
        submitBtn.textContent = "Войти"
      }
    })
  }

  async function checkServerAvailability() {
    try {
      const controller = new AbortController()
      const timeoutId = setTimeout(() => controller.abort(), 5000) // 5 second timeout

      // Используем простой GET запрос вместо HEAD
      const response = await fetch("check_server.php", {
        method: "GET",
        signal: controller.signal,
      })

      clearTimeout(timeoutId)

      if (response.ok) {
        // Если сервер доступен, отключаем демо-режим
        if (demoModeCheckbox) {
          demoModeCheckbox.checked = false
          updateModeDisplay(false)
        }
        console.log("Сервер доступен - серверный режим активирован")
      } else {
        throw new Error("Server not available")
      }
    } catch (error) {
      // Сервер недоступен, включаем демо-режим
      if (demoModeCheckbox) {
        demoModeCheckbox.checked = true
        updateModeDisplay(true)
      }
      console.log("Сервер недоступен - демо-режим активирован")
    }
  }

  function updateModeDisplay(isDemoMode) {
    if (demoCredentials) {
      demoCredentials.style.display = isDemoMode ? "block" : "none"
    }
  }

  // Обработчик переключения режима
  if (demoModeCheckbox) {
    demoModeCheckbox.addEventListener("change", (e) => {
      updateModeDisplay(e.target.checked)
    })
    updateModeDisplay(demoModeCheckbox.checked)
  }

  function authenticateDemo(username, password) {
    // Поиск пользователя по username
    const user = Object.values(DEMO_USERS).find((u) => u.username === username)

    if (!user) {
      return { success: false, message: "Пользователь не найден" }
    }

    if (user.password !== password) {
      return { success: false, message: "Неверный пароль" }
    }

    return {
      success: true,
      user: {
        id: user.id,
        username: user.username,
        email: user.email,
        full_name: user.full_name,
        role: user.role,
        group_number: user.group_number,
      },
    }
  }

  async function authenticateServer(username, password) {
    try {
      const response = await fetch("login.php", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          username: username,
          password: password,
        }),
      })

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`)
      }

      const data = await response.json()
      return data
    } catch (error) {
      console.error("Server authentication error:", error)
      return { success: false, message: "Ошибка соединения с сервером" }
    }
  }

  function getRoleDisplayName(role) {
    const roleNames = {
      student: "студент",
      teacher: "преподаватель",
      admin: "администратор",
    }
    return roleNames[role] || role
  }

  function showSuccessNotification(title, message) {
    if (successNotification) {
      const titleElement = successNotification.querySelector(".notification-text h3")
      const messageElement = successNotification.querySelector(".notification-text p")

      if (titleElement) titleElement.textContent = title
      if (messageElement) messageElement.textContent = message

      successNotification.classList.add("show")

      // Auto hide after 3 seconds
      setTimeout(() => {
        successNotification.classList.remove("show")
      }, 3000)
    }
  }

  function showErrorNotification(title, message) {
    if (errorNotification) {
      const titleElement = errorNotification.querySelector(".notification-text h3")
      const messageElement = errorNotification.querySelector(".notification-text p")

      if (titleElement) titleElement.textContent = title
      if (messageElement) messageElement.textContent = message

      errorNotification.classList.add("show")

      // Auto hide after 4 seconds
      setTimeout(() => {
        errorNotification.classList.remove("show")
      }, 4000)
    }
  }
})
